# FoodBridge

Minimal Python and Flask foundation for T1.1, T1.2, T2.1, T4.1 and T5.2.
There are no routes, frontend pages, registration handlers or login handlers.

## Setup

Use Python 3.9 or newer. Run these commands from the FoodBridge project folder:

```sh
python -m venv .venv
```

Activate the environment with `.venv\Scripts\Activate.ps1` in PowerShell,
or `source .venv/bin/activate` on macOS/Linux. Then run:

```sh
python -m pip install -r requirements.txt
python -m flask --app foodbridge init-db
python -m flask --app foodbridge run
```

Flask is the only direct dependency; pip installs its dependencies automatically.
SQLite is included with Python through `sqlite3`; no separate database server or
SQLite package is needed. The server starts without application routes, so `/`
returns 404 until teammates add their pages.

### VS Code

Open the complete `FoodBridge` folder in VS Code, rather than individual files.
The optional `.vscode/settings.json` points Python discovery at the local `.venv`
directory and disables SQL Server IntelliSense for this SQLite project only.
It also uses the Python extension's built-in environment discovery instead of
the preview Python Environments integration to avoid interpreter recognition
issues observed during setup.
Create and install your own virtual environment as described above; do not copy
another member's `.venv`. If an interpreter was already selected, use
`Python: Select Interpreter` and choose this project's environment. Workspace
Trust is a user-controlled security decision; Restricted Mode may limit extensions.

## Files and task mapping

| Task | Implementation |
| --- | --- |
| T1.1 | `foodbridge/__init__.py`, `foodbridge/db.py`, project folders and generated `instance/foodbridge.db` |
| T1.2 | `users` definition in `foodbridge/schema.sql` |
| T2.1 | `charities` definition in `foodbridge/schema.sql` |
| T4.1 | `donations` definition in `foodbridge/schema.sql` |
| T5.2 | `get_available_donations()` in `foodbridge/donations.py` |

Each table has an integer `id` primary key and only the assigned business fields.
Quantity is numeric (`REAL`); phone and license number are text to preserve
leading zeros. No units, donor links, account status, unique constraints,
mandatory-field rules, or role/status enumerations are imposed here.
Validation and record-saving behavior remain with the corresponding team tasks.
The `password` column is intended for a password hash supplied by T1.4, never
a plaintext password; hashing is not implemented in these tasks.

## Database initialization and recreation

`foodbridge/schema.sql` is the source of the database structure. `init-db` creates
the database folder, database file and missing tables. It may be run again without
deleting existing rows. It does not migrate or change tables that already exist.

To recreate the schema, run `init-db` against a fresh database file. For an existing
local development database, stop the app, back up any data you need, remove the
local database file and run `init-db` again. Do not delete a shared database with
needed data; changes to existing tables require a separately agreed migration.

The default path is resolved from the installed project location to
`instance/foodbridge.db`; it contains no machine-specific paths. A teammate can
override it when constructing the app:

```python
from pathlib import Path
from foodbridge import create_app

app = create_app({"DATABASE": str(Path("instance/team.db").resolve())})
```

Initialize this configured app with `init_db()` inside `app.app_context()`.
Keep one shared database configuration when integrating teammates' modules.

## Expiry time contract and query usage

Store `expiry_time` as TEXT in **exactly** this ISO 8601 UTC format:

```text
YYYY-MM-DDTHH:MM:SS.ffffffZ
2026-10-20T14:30:00.000000Z
```

Always include six fractional-second digits and the literal `Z`. Convert aware
datetimes to UTC before writing. Do not store local time, offsets such as
`+03:00`, a space separator, or timestamps without the fractional part. The query
compares canonical timestamps as text, so all writers must follow this contract.
The schema does not validate timestamp text; validation belongs to the saving
code. Convert the user's local time with its timezone before this step:

```python
from datetime import timezone

# expiry_datetime must already be timezone-aware.
expiry_text = expiry_datetime.astimezone(timezone.utc).strftime(
    "%Y-%m-%dT%H:%M:%S.%fZ"
)
```

Within a Flask application context (including a teammate's future route):

```python
from foodbridge.donations import get_available_donations

donations = get_available_donations()
for donation in donations:
    print(donation["food_type"], donation["expiry_time"])
```

Outside Flask, pass an existing connection:

```python
import sqlite3
from foodbridge.donations import get_available_donations

connection = sqlite3.connect("instance/foodbridge.db")
connection.row_factory = sqlite3.Row
try:
    donations = get_available_donations(connection)
finally:
    connection.close()
```

The helper returns a list of `sqlite3.Row` objects when using the app connection
or a supplied connection configured as above (otherwise the supplied connection's
row format). It returns an empty list when no rows match. Status matching is
case-sensitive and exactly `Available`. Expiry must be strictly later than the
current UTC instant; equality is excluded. NULL expiry/status values do not match.
The helper reads only; it does not update expired records or commit changes.

## Manual integration handoff

Send the complete `foodbridge/` directory, `requirements.txt`, `.gitignore` and
this `README.md`. The included empty `instance/foodbridge.db` demonstrates T1.1
and may be shared, but it is optional for integration and is ignored by Git.
The `.vscode/settings.json` file is optional editor configuration. Do not send
the local `.venv` directory; it contains machine-specific environment files.

Merge the application factory, connection lifecycle and `init-db` registration,
the three table definitions, and the T5.2 helper. If the team has created an app
factory in parallel, merge the configuration and `db.init_app(app)` call into
that factory instead of replacing their work. Reconcile existing table definitions
before running initialization; `CREATE TABLE IF NOT EXISTS` cannot reconcile
different column definitions. Preserve teammates' modules and dependencies.

On a fresh integration checkout, install `requirements.txt` and run
`python -m flask --app foodbridge init-db`. This creates the database from code;
copying the supplied `.db` file is unnecessary. If the team's existing database
already matches these definitions, recreation is unnecessary. For incompatible
existing tables, agree on a migration or recreate only a disposable development
database after backing up any needed data.

The references describe broader Sprint 1 work, but this implementation deliberately
covers only the five approved tasks. Team merge and independent teammate review
remain integration activities; no shared repository was provided here.

## Verification performed

Verified with Python 3.12 and Flask 3.1.3: Flask CLI initialization; exact table
columns and primary keys; initialization preserving existing rows; independent
recreation from `schema.sql`; available future donations included; expired,
equal-time, collected, requested, lowercase-status and NULL values excluded;
empty results; use inside and outside Flask; connection cleanup; and generated
database integrity. Verification used temporary databases, leaving the delivered
database empty. The app registers no routes.
