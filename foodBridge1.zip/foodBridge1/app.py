from flask import Flask, render_template, request, redirect, url_for, flash, session
import sqlite3

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        password = request.form.get('password')
        
        conn = get_db_connection()
        conn.execute('INSERT INTO users (name, email, phone, password) VALUES (?, ?, ?, ?)',
                     (name, email, phone, password))
        conn.commit()
        conn.close()
        
        return redirect(url_for('login'))
        
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE email = ? AND password = ?', 
                            (email, password)).fetchone()
        conn.close()
        
        if user:
            return redirect(url_for('donor_dashboard'))
        else:
            return "Invalid email or password", 400
            
    return render_template('login.html')

@app.route('/donor_request', methods=['GET', 'POST'])
def donor_request():
    if request.method == 'POST':
        food_type = request.form.get('food_type')
        quantity = request.form.get('quantity')
        
        conn = get_db_connection()
        conn.execute('INSERT INTO requests (food_type, quantity) VALUES (?, ?)', 
                     (food_type, quantity))
        conn.commit()
        conn.close()
        
        return redirect(url_for('donor_dashboard'))
        
    return render_template('donor_request.html')

@app.route('/donor_dashboard', methods=['GET'])
def donor_dashboard():
    return render_template('donor_dashboard.html')

if __name__ == '__main__':
    app.run(debug=True)